fx_version 'cerulean'
game 'gta5'

author 'Jumbo-modding'
description 'Suomenliput'
version '1.0.0'

this_is_a_map 'yes'